DEFAULT_BUILD_SCRIPT = 'hatch_build.py'
DEFAULT_CONFIG_FILE = 'hatch.toml'
