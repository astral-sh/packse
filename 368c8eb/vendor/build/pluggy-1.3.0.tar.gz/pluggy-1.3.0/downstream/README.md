This directory contains scripts for testing some downstream projects
against your current pluggy worktree.
